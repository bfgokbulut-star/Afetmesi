package com.afetmesh.app

import android.Manifest
import android.hardware.Sensor
import android.hardware.SensorManager
import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.BatteryManager
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.google.android.gms.nearby.Nearby
import com.google.android.gms.nearby.connection.AdvertisingOptions
import com.google.android.gms.nearby.connection.ConnectionInfo
import com.google.android.gms.nearby.connection.ConnectionLifecycleCallback
import com.google.android.gms.nearby.connection.ConnectionResolution
import com.google.android.gms.nearby.connection.ConnectionsClient
import com.google.android.gms.nearby.connection.DiscoveredEndpointInfo
import com.google.android.gms.nearby.connection.DiscoveryOptions
import com.google.android.gms.nearby.connection.EndpointDiscoveryCallback
import com.google.android.gms.nearby.connection.Payload
import com.google.android.gms.nearby.connection.PayloadCallback
import com.google.android.gms.nearby.connection.PayloadTransferUpdate
import com.google.android.gms.nearby.connection.Strategy
import java.util.Collections
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

/**
 * Mesh çekirdeği.
 *
 * - Nearby Connections (P2P_CLUSTER) ile yakındaki AfetMesh cihazlarını bulur ve bağlanır.
 * - Mesajlar "flooding" ile yayılır: alan cihaz, daha önce görmediyse bağlı herkese iletir.
 * - TTL atlama sayısını sınırlar, mesaj id'si döngüyü engeller.
 * - Store-and-forward: son mesajlar saklanır, yeni bir cihaz bağlanınca ona da verilir.
 */
class MeshService : Service() {

    companion object {
        const val ACTION_START = "afetmesh.START"
        const val ACTION_STOP = "afetmesh.STOP"
        const val ACTION_SEND = "afetmesh.SEND"
        const val ACTION_SOS_ON = "afetmesh.SOS_ON"
        const val ACTION_SOS_OFF = "afetmesh.SOS_OFF"
        const val ACTION_SEND_VOICE = "afetmesh.SEND_VOICE"
        const val ACTION_SETTINGS = "afetmesh.SETTINGS"
        const val ACTION_QUAKE_TEST = "afetmesh.QUAKE_TEST"
        const val ACTION_QUAKE_CANCEL = "afetmesh.QUAKE_CANCEL"
        const val EXTRA_TO = "to"
        const val EXTRA_TEXT = "text"
        const val EXTRA_AUDIO = "audio"
        private const val QUAKE_NOTIF_ID = 99
        private const val QUAKE_CANCEL_WINDOW_MS = 60_000L

        private const val SERVICE_ID = "com.afetmesh.app.mesh"
        private const val MAX_TTL = 12
        private const val SOS_INTERVAL_MS = 30_000L
        private const val CH_MAIN = "mesh"
        private const val CH_SOS = "sos"

        fun send(ctx: Context, action: String, to: String = "", text: String = "", audio: String? = null) {
            val i = Intent(ctx, MeshService::class.java)
                .setAction(action)
                .putExtra(EXTRA_TO, to)
                .putExtra(EXTRA_TEXT, text)
            if (audio != null) i.putExtra(EXTRA_AUDIO, audio)
            ContextCompat.startForegroundService(ctx, i)
        }
    }

    private lateinit var client: ConnectionsClient
    private val handler = Handler(Looper.getMainLooper())

    private val code: String get() = MeshState.myCode

    private val peers = ConcurrentHashMap<String, String>()   // endpointId -> kod
    private val pending = ConcurrentHashMap<String, String>() // bağlanmakta olanlar
    private val known = ConcurrentHashMap<String, String>()   // keşfedilenler

    private val seen: MutableMap<String, Boolean> = Collections.synchronizedMap(
        object : LinkedHashMap<String, Boolean>() {
            override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, Boolean>?): Boolean =
                size > 2000
        }
    )
    private val buffer = ArrayList<Message>()

    private var sosText = ""
    private var lastLoc: Location? = null

    override fun onCreate() {
        super.onCreate()
        MeshState.ensureCode(this)
        client = Nearby.getConnectionsClient(this)
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        ensureForeground()
        when (intent?.action) {
            ACTION_STOP -> {
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_SEND -> {
                startMesh()
                val text = intent?.getStringExtra(EXTRA_TEXT).orEmpty().trim()
                val to = intent?.getStringExtra(EXTRA_TO).orEmpty().trim().uppercase()
                if (text.isNotEmpty()) originate(MsgType.TEXT, to, text)
            }
            ACTION_SOS_ON -> {
                startMesh()
                startSos(intent?.getStringExtra(EXTRA_TEXT).orEmpty())
            }
            ACTION_SEND_VOICE -> {
                startMesh()
                val audio = intent?.getStringExtra(EXTRA_AUDIO)
                val to = intent?.getStringExtra(EXTRA_TO).orEmpty().trim().uppercase()
                if (!audio.isNullOrEmpty()) originate(MsgType.VOICE, to, "Sesli not", audio)
            }
            ACTION_SOS_OFF -> stopSos()
            ACTION_SETTINGS -> applyQuakeSetting()
            ACTION_QUAKE_TEST -> {
                startMesh()
                onQuake()
            }
            ACTION_QUAKE_CANCEL -> cancelQuake()
            else -> startMesh()
        }
        return START_STICKY
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        stopLocationUpdates()
        stopQuake()
        client.stopAdvertising()
        client.stopDiscovery()
        client.stopAllEndpoints()
        peers.clear(); pending.clear(); known.clear()
        MeshState.running.value = false
        MeshState.sosActive.value = false
        MeshState.peerCount.value = 0
        MeshState.status.value = "Durduruldu"
        super.onDestroy()
    }

    // ---------------------------------------------------------------- Nearby

    private fun startMesh() {
        if (MeshState.running.value) return
        MeshState.running.value = true
        MeshState.status.value = "Yakındaki cihazlar aranıyor"
        applyQuakeSetting()

        client.startAdvertising(
            code, SERVICE_ID, connCb,
            AdvertisingOptions.Builder().setStrategy(Strategy.P2P_CLUSTER).build()
        ).addOnFailureListener { MeshState.status.value = "Yayın hatası: ${it.message}" }

        client.startDiscovery(
            SERVICE_ID, discCb,
            DiscoveryOptions.Builder().setStrategy(Strategy.P2P_CLUSTER).build()
        ).addOnFailureListener { MeshState.status.value = "Arama hatası: ${it.message}" }
    }

    private val discCb = object : EndpointDiscoveryCallback() {
        override fun onEndpointFound(id: String, info: DiscoveredEndpointInfo) {
            val remote = info.endpointName
            if (remote == code) return
            known[id] = remote
            // Çakışmayı azaltmak için kodu küçük olan hemen, büyük olan 3 sn sonra bağlanır.
            handler.postDelayed({ tryConnect(id) }, if (code < remote) 0L else 3000L)
        }

        override fun onEndpointLost(id: String) {
            known.remove(id)
        }
    }

    private fun tryConnect(id: String) {
        val remote = known[id] ?: return
        if (peers.containsKey(id) || pending.containsKey(id)) return
        pending[id] = remote
        client.requestConnection(code, id, connCb).addOnFailureListener {
            pending.remove(id)
            handler.postDelayed({ tryConnect(id) }, 8000)
        }
    }

    private val connCb = object : ConnectionLifecycleCallback() {
        override fun onConnectionInitiated(id: String, info: ConnectionInfo) {
            pending[id] = info.endpointName
            // Acil durumda doğrulama istemiyoruz; herkes bağlanabilsin.
            client.acceptConnection(id, payloadCb)
        }

        override fun onConnectionResult(id: String, result: ConnectionResolution) {
            val name = pending.remove(id) ?: known[id] ?: "?"
            if (result.status.isSuccess) {
                peers[id] = name
                updateCount()
                flushBufferTo(id)
            } else {
                handler.postDelayed({ tryConnect(id) }, 8000)
            }
        }

        override fun onDisconnected(id: String) {
            peers.remove(id)
            updateCount()
            handler.postDelayed({ tryConnect(id) }, 5000)
        }
    }

    private fun updateCount() {
        MeshState.peerCount.value = peers.size
        MeshState.status.value =
            if (peers.isEmpty()) "Yakındaki cihazlar aranıyor" else "Ağ aktif"
    }

    private val payloadCb = object : PayloadCallback() {
        override fun onPayloadReceived(endpointId: String, payload: Payload) {
            val bytes = payload.asBytes() ?: return
            val m = Message.fromBytes(bytes) ?: return
            handleIncoming(m, endpointId)
        }

        override fun onPayloadTransferUpdate(endpointId: String, update: PayloadTransferUpdate) {}
    }

    // ---------------------------------------------------------------- Mesh mantığı

    private fun handleIncoming(m: Message, fromEndpoint: String) {
        if (seen.put(m.id, true) != null) return // zaten gördük
        if (m.from == code) return

        val forMe = m.to.isEmpty() || m.to == code
        if (forMe) deliver(m)

        // Sadece bana gelen mesaj zincirde durur; diğerleri iletilmeye devam eder.
        if (m.to != code && m.ttl > 0) {
            remember(m)
            relay(m, except = fromEndpoint)
        }
    }

    private fun originate(type: MsgType, to: String, text: String, audio: String? = null) {
        val loc = bestLocation()
        val m = Message(
            id = UUID.randomUUID().toString(),
            from = code, to = to, type = type, text = text,
            lat = loc?.latitude, lon = loc?.longitude,
            battery = battery(),
            ttl = MAX_TTL, maxTtl = MAX_TTL,
            time = System.currentTimeMillis(),
            audio = audio,
        )
        seen[m.id] = true
        remember(m) // bağlı kimse yoksa sonradan bağlananlara iletilir
        if (type != MsgType.SOS) MeshState.add(m)
        relay(m, except = null)
    }

    /** m.ttl bir azaltılarak bağlı herkese (except hariç) gönderilir. */
    private fun relay(m: Message, except: String?) {
        if (m.ttl <= 0) return
        val bytes = m.copy(ttl = m.ttl - 1).toBytes()
        peers.keys.filter { it != except }.forEach { client.sendPayload(it, Payload.fromBytes(bytes)) }
    }

    private fun flushBufferTo(id: String) {
        val copy = synchronized(buffer) { buffer.toList() }
        copy.forEach { m ->
            if (m.ttl > 0) client.sendPayload(id, Payload.fromBytes(m.copy(ttl = m.ttl - 1).toBytes()))
        }
    }

    private fun remember(m: Message) = synchronized(buffer) {
        val now = System.currentTimeMillis()
        buffer.removeAll {
            it.id == m.id ||
                (m.type == MsgType.SOS && it.type == MsgType.SOS && it.from == m.from) ||
                now - it.time > 24 * 3600_000L
        }
        buffer.add(m)
        while (buffer.size > 300) buffer.removeAt(0)
        // Sesli notlar büyük: en fazla 10 tanesi saklanır
        while (buffer.count { it.type == MsgType.VOICE } > 10) {
            buffer.removeAt(buffer.indexOfFirst { it.type == MsgType.VOICE })
        }
    }

    private fun deliver(m: Message) {
        MeshState.add(m)
        if (m.type == MsgType.SOS) {
            alert(m.from.hashCode(), "SOS: ${m.from}", "${m.text} (%${m.battery} pil, ${m.hops} atlama)")
        } else if (m.to == code) {
            alert(m.from.hashCode() + 1, "Mesaj: ${m.from}", m.text)
        }
    }

    // ---------------------------------------------------------------- SOS

    private val sosTick = object : Runnable {
        override fun run() {
            if (!MeshState.sosActive.value) return
            originate(MsgType.SOS, "", sosText)
            // Pil azaldıkça yayın seyrekleşir (enkazda pil ömrü kritik)
            val b = battery()
            val interval = when {
                b in 0..10 -> SOS_INTERVAL_MS * 4
                b in 0..20 -> SOS_INTERVAL_MS * 2
                else -> SOS_INTERVAL_MS
            }
            handler.postDelayed(this, interval)
        }
    }

    private fun startSos(note: String) {
        sosText = note.ifBlank { "Enkaz altındayım, yardım edin" }
        if (MeshState.sosActive.value) return
        MeshState.sosActive.value = true
        startLocationUpdates()
        handler.post(sosTick)
    }

    private fun stopSos() {
        MeshState.sosActive.value = false
        handler.removeCallbacks(sosTick)
        stopLocationUpdates()
    }

    // ---------------------------------------------------------------- Deprem algılama

    private var detector: QuakeDetector? = null
    private var wakeLock: PowerManager.WakeLock? = null

    /** Deprem sonrası kullanıcı "İyiyim" demezse SOS kendiliğinden başlar. */
    private val quakeSos = Runnable {
        cancelQuakeNotice()
        MeshState.status.value = "Otomatik SOS başlatıldı"
        startSos("Deprem sonrası otomatik SOS: yanıt veremiyor olabilirim")
    }

    @SuppressLint("WakelockTimeout")
    private fun applyQuakeSetting() {
        val want = MeshState.quakeEnabled.value && MeshState.running.value
        if (want && detector == null) {
            val sm = getSystemService(SensorManager::class.java)
            val sensor = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER) ?: return
            val d = QuakeDetector { handler.post { onQuake() } }
            sm.registerListener(d, sensor, SensorManager.SENSOR_DELAY_GAME)
            detector = d
            // Ekran kapalıyken (gece şarjda) ivmeölçer verisi kesilmesin diye CPU uyanık tutulur.
            wakeLock = getSystemService(PowerManager::class.java)
                .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "afetmesh:quake")
                .apply {
                    setReferenceCounted(false)
                    acquire()
                }
        } else if (!want) {
            stopQuake()
        }
    }

    private fun stopQuake() {
        detector?.let { getSystemService(SensorManager::class.java).unregisterListener(it) }
        detector = null
        wakeLock?.let { if (it.isHeld) it.release() }
        wakeLock = null
    }

    private fun onQuake() {
        MeshState.status.value = "Deprem algılandı!"
        val cancel = PendingIntent.getForegroundService(
            this, 2,
            Intent(this, MeshService::class.java).setAction(ACTION_QUAKE_CANCEL),
            PendingIntent.FLAG_IMMUTABLE
        )
        val n = NotificationCompat.Builder(this, CH_SOS)
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentTitle("Deprem algılandı!")
            .setContentText("İyiyseniz 60 sn içinde 'İyiyim'e basın, yoksa SOS otomatik başlar.")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setOngoing(true)
            .setContentIntent(openAppIntent())
            .addAction(0, "İyiyim", cancel)
            .build()
        getSystemService(NotificationManager::class.java).notify(QUAKE_NOTIF_ID, n)
        handler.removeCallbacks(quakeSos)
        handler.postDelayed(quakeSos, QUAKE_CANCEL_WINDOW_MS)
    }

    private fun cancelQuake() {
        handler.removeCallbacks(quakeSos)
        cancelQuakeNotice()
        updateCount()
    }

    private fun cancelQuakeNotice() {
        getSystemService(NotificationManager::class.java).cancel(QUAKE_NOTIF_ID)
    }

    // ---------------------------------------------------------------- Konum / pil

    private val locListener = object : LocationListener {
        override fun onLocationChanged(l: Location) {
            lastLoc = l
        }

        @Deprecated("Deprecated in Java")
        override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
        override fun onProviderEnabled(provider: String) {}
        override fun onProviderDisabled(provider: String) {}
    }

    private fun hasLocation(): Boolean =
        ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

    @SuppressLint("MissingPermission")
    private fun startLocationUpdates() {
        if (!hasLocation()) return
        try {
            getSystemService(LocationManager::class.java).requestLocationUpdates(
                LocationManager.GPS_PROVIDER, 30_000L, 0f, locListener, Looper.getMainLooper()
            )
        } catch (_: Exception) {
        }
    }

    private fun stopLocationUpdates() {
        try {
            getSystemService(LocationManager::class.java).removeUpdates(locListener)
        } catch (_: Exception) {
        }
    }

    @SuppressLint("MissingPermission")
    private fun bestLocation(): Location? {
        if (!hasLocation()) return null
        val lm = getSystemService(LocationManager::class.java)
        val fromProviders = listOf(
            LocationManager.GPS_PROVIDER,
            LocationManager.NETWORK_PROVIDER,
            LocationManager.PASSIVE_PROVIDER,
        ).mapNotNull { p -> try { lm.getLastKnownLocation(p) } catch (_: Exception) { null } }
        return (listOfNotNull(lastLoc) + fromProviders).maxByOrNull { it.time }
    }

    private fun battery(): Int =
        getSystemService(BatteryManager::class.java).getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)

    // ---------------------------------------------------------------- Bildirimler

    private fun openAppIntent(): PendingIntent = PendingIntent.getActivity(
        this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
    )

    private fun ensureForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH_MAIN, "Mesh ağı", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel(CH_SOS, "SOS uyarıları", NotificationManager.IMPORTANCE_HIGH))

        val n = NotificationCompat.Builder(this, CH_MAIN)
            .setSmallIcon(android.R.drawable.stat_sys_data_bluetooth)
            .setContentTitle("AfetMesh çalışıyor")
            .setContentText("Kodunuz: ${MeshState.myCode}")
            .setOngoing(true)
            .setContentIntent(openAppIntent())
            .build()

        var type = 0
        if (android.os.Build.VERSION.SDK_INT >= 29) {
            type = ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE
            if (hasLocation()) type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION
        }
        ServiceCompat.startForeground(this, 1, n, type)
    }

    private fun alert(id: Int, title: String, text: String) {
        val n = NotificationCompat.Builder(this, CH_SOS)
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentTitle(title)
            .setContentText(text)
            .setAutoCancel(true)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(openAppIntent())
            .build()
        getSystemService(NotificationManager::class.java).notify(id, n)
    }
}
