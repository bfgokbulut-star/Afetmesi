package com.afetmesh.app

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.Base64
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        MeshState.ensureCode(this)
        setContent {
            MaterialTheme {
                Surface(Modifier.fillMaxSize()) { MeshScreen() }
            }
        }
    }
}

// ------------------------------------------------------------------ İzinler

/** Mesh'in çalışması için şart olanlar. */
private fun corePermissions(): List<String> = buildList {
    if (Build.VERSION.SDK_INT >= 31) {
        add(Manifest.permission.BLUETOOTH_SCAN)
        add(Manifest.permission.BLUETOOTH_ADVERTISE)
        add(Manifest.permission.BLUETOOTH_CONNECT)
    } else {
        add(Manifest.permission.ACCESS_FINE_LOCATION)
    }
    if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.NEARBY_WIFI_DEVICES)
}

/** İstenecek tüm izinler (konum ve bildirim opsiyonel ama önerilir). */
private fun allPermissions(): Array<String> = buildList {
    addAll(corePermissions())
    add(Manifest.permission.ACCESS_FINE_LOCATION)
    add(Manifest.permission.ACCESS_COARSE_LOCATION)
    if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
}.distinct().toTypedArray()

private fun hasCore(ctx: Context): Boolean = corePermissions().all {
    ContextCompat.checkSelfPermission(ctx, it) == PackageManager.PERMISSION_GRANTED
}

private fun openMap(ctx: Context, lat: Double, lon: Double) {
    try {
        ctx.startActivity(
            Intent(Intent.ACTION_VIEW, Uri.parse("geo:$lat,$lon?q=$lat,$lon(SOS)"))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    } catch (_: Exception) {
        Toast.makeText(ctx, "Harita uygulaması bulunamadı", Toast.LENGTH_SHORT).show()
    }
}

// ------------------------------------------------------------------ Ekran

@Composable
fun MeshScreen() {
    val ctx = LocalContext.current
    val messages by MeshState.messages.collectAsState()
    val peers by MeshState.peerCount.collectAsState()
    val running by MeshState.running.collectAsState()
    val sos by MeshState.sosActive.collectAsState()
    val status by MeshState.status.collectAsState()
    val quake by MeshState.quakeEnabled.collectAsState()

    var to by remember { mutableStateOf("") }
    var text by remember { mutableStateOf("") }
    var pending by remember { mutableStateOf<(() -> Unit)?>(null) }

    val launcher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) {
        if (hasCore(ctx)) pending?.invoke()
        else Toast.makeText(ctx, "Bluetooth/Yakındaki cihazlar izni gerekli", Toast.LENGTH_LONG).show()
        pending = null
    }

    fun withPerms(action: () -> Unit) {
        if (hasCore(ctx)) action() else {
            pending = action
            launcher.launch(allPermissions())
        }
    }

    // ---- Sesli not
    var recorder by remember { mutableStateOf<VoiceRecorder?>(null) }

    fun finishRecording() {
        val r = recorder ?: return
        recorder = null
        val bytes = r.stop()
        if (bytes == null || bytes.size < 300) {
            Toast.makeText(ctx, "Kayıt alınamadı", Toast.LENGTH_SHORT).show()
            return
        }
        val b64 = Base64.encodeToString(bytes, Base64.NO_WRAP)
        withPerms { MeshService.send(ctx, MeshService.ACTION_SEND_VOICE, to, audio = b64) }
    }

    fun startRecording() {
        try {
            recorder = VoiceRecorder(ctx).also { it.start() }
        } catch (e: Exception) {
            Toast.makeText(ctx, "Mikrofon başlatılamadı", Toast.LENGTH_SHORT).show()
        }
    }

    val audioLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { ok ->
        if (ok) startRecording()
        else Toast.makeText(ctx, "Mikrofon izni gerekli", Toast.LENGTH_SHORT).show()
    }

    // 10 sn dolunca kayıt otomatik biter ve gönderilir
    LaunchedEffect(recorder) {
        if (recorder != null) {
            delay(10_000)
            finishRecording()
        }
    }

    val sosList = messages.filter { it.type == MsgType.SOS }.sortedByDescending { it.time }
    val chat = messages.filter { it.type != MsgType.SOS }

    Column(
        Modifier
            .fillMaxSize()
            .systemBarsPadding()
            .imePadding()
            .padding(12.dp)
    ) {
        Text("AfetMesh", style = MaterialTheme.typography.titleMedium)
        Text(
            "Kodum: ${MeshState.myCode}",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold
        )
        Text("$status • Bağlı cihaz: $peers")
        Spacer(Modifier.padding(4.dp))

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = {
                if (running) MeshService.send(ctx, MeshService.ACTION_STOP)
                else withPerms { MeshService.send(ctx, MeshService.ACTION_START) }
            }) { Text(if (running) "Ağı durdur" else "Ağı başlat") }

            Button(
                onClick = {
                    if (sos) MeshService.send(ctx, MeshService.ACTION_SOS_OFF)
                    else withPerms { MeshService.send(ctx, MeshService.ACTION_SOS_ON) }
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFC62828))
            ) { Text(if (sos) "SOS'u durdur" else "SOS GÖNDER") }
        }
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Switch(
                checked = quake,
                onCheckedChange = {
                    MeshState.setQuake(ctx, it)
                    if (running) MeshService.send(ctx, MeshService.ACTION_SETTINGS)
                }
            )
            Spacer(Modifier.width(8.dp))
            Text("Deprem algılama", Modifier.weight(1f))
            TextButton(onClick = {
                withPerms { MeshService.send(ctx, MeshService.ACTION_QUAKE_TEST) }
            }) { Text("Test") }
        }
        Spacer(Modifier.padding(4.dp))

        LazyColumn(
            Modifier
                .weight(1f)
                .fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            item {
                Text(
                    "Alınan SOS sinyalleri (${sosList.size})",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )
            }
            items(sosList, key = { it.id }) { m ->
                val minutes = (System.currentTimeMillis() - m.time) / 60_000
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFFEBEE)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(Modifier.padding(10.dp)) {
                        Text("${m.from}: ${m.text}", fontWeight = FontWeight.Bold)
                        Text("%${m.battery} pil • ${m.hops} atlama • $minutes dk önce")
                        if (m.lat != null && m.lon != null) {
                            Text("Konum: %.5f, %.5f".format(m.lat, m.lon))
                            TextButton(onClick = { openMap(ctx, m.lat, m.lon) }) { Text("Haritada aç") }
                        } else {
                            Text("Konum bilgisi yok")
                        }
                    }
                }
            }
            item {
                Text(
                    "Mesajlar",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )
            }
            items(chat, key = { it.id }) { m ->
                val who = if (m.from == MeshState.myCode) "Ben" else m.from
                val target = if (m.to.isEmpty()) "herkes" else m.to
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        "$who → $target (${m.hops} atlama): ${m.text}",
                        Modifier.weight(1f, fill = false)
                    )
                    if (m.type == MsgType.VOICE && m.audio != null) {
                        TextButton(onClick = { VoicePlayer.play(ctx, m.audio) }) { Text("Dinle") }
                    }
                }
            }
        }

        OutlinedTextField(
            value = to,
            onValueChange = { to = it.uppercase().take(6) },
            label = { Text("Hedef kod (boş = herkese)") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Row(Modifier.fillMaxWidth()) {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                label = { Text("Mesaj") },
                modifier = Modifier.weight(1f)
            )
            Spacer(Modifier.width(8.dp))
            Button(
                onClick = {
                    if (text.isNotBlank()) withPerms {
                        MeshService.send(ctx, MeshService.ACTION_SEND, to, text)
                        text = ""
                    }
                },
                modifier = Modifier.padding(top = 8.dp)
            ) { Text("Gönder") }
        }
        Button(
            onClick = {
                if (recorder != null) finishRecording()
                else if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO)
                    == PackageManager.PERMISSION_GRANTED
                ) startRecording()
                else audioLauncher.launch(Manifest.permission.RECORD_AUDIO)
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(
                if (recorder != null) "Kaydı bitir ve gönder (en fazla 10 sn)"
                else "Sesli not kaydet (10 sn)"
            )
        }
    }
}
